// Recursive DFS maze solver with backtracking

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Cell.h"
#include "helpers.h"
#include "Maze.h"

bool solve(Maze m) {
    // TODO: Complete this function
    //       Feel free to add helper functions
    return false;
}

