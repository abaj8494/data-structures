// Interface to the maze solver

// !!! DO NOT MODIFY THIS FILE !!!

#ifndef SOLVER_H
#define SOLVER_H

#include <stdbool.h>

#include "Maze.h"

bool solve(Maze m);

#endif
