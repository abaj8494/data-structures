// Definition of the Cell data type

// !!! DO NOT MODIFY THIS FILE !!!

#ifndef CELL_H
#define CELL_H

typedef struct cell {
    int row;
    int col;
} Cell;

#endif
